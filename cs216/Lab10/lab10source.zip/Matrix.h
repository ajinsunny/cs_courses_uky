//File: Matrix.h
//Purpose: to declare the class Matrix
//Author: (your name)

#ifndef MATRIX_H
#define	MATRIX_H

class Matrix
{
  public:
	Matrix(int sizeX, int sizeY);
	~Matrix();
	int GetSizeX() const { return dx; }
	int GetSizeY() const { return dy; }
	long &Element(int x, int y);        // return reference to an element
	void Print() const;
  private:
	long **p;       // pointer to a pointer to a long integer
	int dx, dy;
};

#endif	/* MATRIX_H */

